package baithi;

public class Main {
    public static void main(String[] args){
        Hotel hotel = new Hotel();
        hotel.EnterHotel();
        hotel.InforHotel();

        Hotel hotel1 = new Hotel();
        hotel.EnterHotel();





    }


}

